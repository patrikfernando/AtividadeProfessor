export interface connreq {
    sender: string;
    recipient: string;
}