export var config = {
    apiKey: <apiKey>,
    authDomain: <yourauthDomain>,
    databaseURL: <yourdatabaseURL>,
    projectId: <yourprojectId>,
    storageBucket: <yourstoragebucket>,
    messagingSenderId: <yoursenderIdhere>
  };